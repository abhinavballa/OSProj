#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

struct alumno{
	char nombre[50];
	int nota;
	int convocatoria;
};




int cmp_students(const void *a, const void *b) {
    struct alumno *s1 = (struct alumno *)a;
    struct alumno *s2 = (struct alumno *)b;
    return s1->nota - s2->nota;  // Ascending order by nota

}

int main(int argc, char *argv[]){
    // Check args count
    if (argc != 4) {
        return -1;
    }
    
    // Open input files
    int fd1 = open(argv[1], O_RDONLY);
    if (fd1 == -1) {
        return -1;
    }
    
    int fd2 = open(argv[2], O_RDONLY);
    if (fd2 == -1) {
        close(fd1);
        return -1;
    }
    
    // Open output file
    int fd_out = open(argv[3], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd_out == -1) {
        close(fd1);
        close(fd2);
        return -1;
    }
    
    // Read all students
    struct alumno all_students[100];
    int student_count = 0;
    
    // Read first file
    struct alumno temp;
    while (read(fd1, &temp, sizeof(struct alumno)) == sizeof(struct alumno)) {
        if (student_count >= 100) {
            printf("Error: Maximum number of students (100) exceeded\n");
            close(fd1);
            close(fd2);
            close(fd_out);
            return -1;
        }
        
        // Check if student already exists
        int duplicate = 0;
        for (int i = 0; i < student_count; i++) {
            if (strcmp(all_students[i].nombre, temp.nombre) == 0) {
                duplicate = 1;
                break;
            }
        }
        
        if (!duplicate) {
            all_students[student_count++] = temp;
        }
    }
    
    // Read second file
    while (read(fd2, &temp, sizeof(struct alumno)) == sizeof(struct alumno)) {
        if (student_count >= 100) {
            printf("Error: Maximum number of students (100) exceeded\n");
            close(fd1);
            close(fd2);
            close(fd_out);
            return -1;
        }
        
        // Check if student already exists
        int duplicate = 0;
        for (int i = 0; i < student_count; i++) {
            if (strcmp(all_students[i].nombre, temp.nombre) == 0) {
                duplicate = 1;
                break;
            }
        }
        
        if (!duplicate) {
            all_students[student_count++] = temp;
        }
    }
    
    // Sort students by grade (ascending)
    qsort(all_students, student_count, sizeof(struct alumno), cmp_students);
    
    // Write sorted data to output file
    write(fd_out, all_students, sizeof(struct alumno) * student_count);
    
    // Close file descriptors
    close(fd1);
    close(fd2);
    close(fd_out);
    
    // Calculate statistics
    int m_count = 0; // Score 10
    int s_count = 0; // Score 9
    int n_count = 0; // Score 7-8
    int a_count = 0; // Score 5-6
    int f_count = 0; // Score < 5
    
    for (int i = 0; i < student_count; i++) {
        int grade = all_students[i].nota;
        if (grade == 10) m_count++;
        else if (grade == 9) s_count++;
        else if (grade == 8 || grade == 7) n_count++;
        else if (grade == 6 || grade == 5) a_count++;
        else f_count++;
    }
    
    // Create statistics file
    FILE *stats_file = fopen("estadisticas.csv", "w");
    if (stats_file == NULL) {
        return -1;
    }
    
    // Write statistics
	if (student_count > 0) {
        fprintf(stats_file, "M;%d;%.2f%%\n", m_count, (float)m_count * 100 / student_count);
        fprintf(stats_file, "S;%d;%.2f%%\n", s_count, (float)s_count * 100 / student_count);
        fprintf(stats_file, "N;%d;%.2f%%\n", n_count, (float)n_count * 100 / student_count);
        fprintf(stats_file, "A;%d;%.2f%%\n", a_count, (float)a_count * 100 / student_count);
        fprintf(stats_file, "F;%d;%.2f%%\n", f_count, (float)f_count * 100 / student_count);
    }
    
    fclose(stats_file);
    return 0;

}
